#include <Windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include <iostream>

#include "imgui.h"
#include "backends/imgui_impl_win32.h"
#include "backends/imgui_impl_dx11.h"
#include "../MenuDLL/Menu.h"
#include "../MenuDLL/HookLab.h"

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")

static ID3D11Device* g_device = nullptr;
static ID3D11DeviceContext* g_context = nullptr;
static IDXGISwapChain* g_swap = nullptr;
static ID3D11RenderTargetView* g_target = nullptr;
static HWND g_hwnd = nullptr;
static bool g_running = true;
static HookLab::HostState g_hostState{};

extern "C" LRESULT ImGui_ImplWin32_WndProcHandler(
    HWND, UINT, WPARAM, LPARAM);

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    if (ImGui_ImplWin32_WndProcHandler(hwnd, msg, wParam, lParam))
        return true;

    if (msg == WM_DESTROY)
    {
        g_running = false;
        PostQuitMessage(0);
        return 0;
    }

    return DefWindowProc(hwnd, msg, wParam, lParam);
}

bool CreateDevice()
{
    DXGI_SWAP_CHAIN_DESC sd{};
    sd.BufferCount = 2;
    sd.BufferDesc.Width = 0;
    sd.BufferDesc.Height = 0;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = g_hwnd;
    sd.SampleDesc.Count = 1;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

    D3D_FEATURE_LEVEL level;

    return SUCCEEDED(D3D11CreateDeviceAndSwapChain(
        nullptr,
        D3D_DRIVER_TYPE_HARDWARE,
        nullptr,
        0,
        nullptr,
        0,
        D3D11_SDK_VERSION,
        &sd,
        &g_swap,
        &g_device,
        &level,
        &g_context));
}

void CreateTarget()
{
    ID3D11Texture2D* backBuffer = nullptr;

    g_swap->GetBuffer(
        0,
        IID_PPV_ARGS(&backBuffer));

    g_device->CreateRenderTargetView(
        backBuffer,
        nullptr,
        &g_target);

    backBuffer->Release();
}

void Cleanup()
{
    Menu::Shutdown();

    if (g_target) g_target->Release();
    if (g_swap) g_swap->Release();
    if (g_context) g_context->Release();
    if (g_device) g_device->Release();
}

int WINAPI WinMain(
    HINSTANCE instance,
    HINSTANCE,
    LPSTR,
    int)
{
    WNDCLASSEX wc{
        sizeof(WNDCLASSEX),
        CS_CLASSDC,
        WndProc,
        0,
        0,
        instance,
        nullptr,
        nullptr,
        nullptr,
        nullptr,
        L"MenuLabHost",
        nullptr
    };

    RegisterClassEx(&wc);

    g_hwnd = CreateWindowW(
        wc.lpszClassName,
        L"Menu DLL Lab - DX11 Test Host",
        WS_OVERLAPPEDWINDOW,
        100,
        100,
        1280,
        720,
        nullptr,
        nullptr,
        instance,
        nullptr);

    if (!CreateDevice())
        return 1;

    CreateTarget();

    ShowWindow(g_hwnd, SW_SHOWDEFAULT);
    UpdateWindow(g_hwnd);

    HMODULE dll = LoadLibraryW(L"MenuDLL.dll");

    if (!dll)
    {
        MessageBoxW(
            g_hwnd,
            L"MenuDLL.dll could not be loaded.",
            L"Error",
            MB_ICONERROR);

        Cleanup();
        return 1;
    }

    if (!Menu::Initialize(
        g_hwnd,
        g_device,
        g_context))
    {
        FreeLibrary(dll);
        Cleanup();
        return 1;
    }

    bool previousInsert = false;

    while (g_running)
    {
        MSG msg{};

        while (PeekMessage(
            &msg,
            nullptr,
            0,
            0,
            PM_REMOVE))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }

        // Simulated game tick. This is the only state exposed to the DLL.
        ++g_hostState.tick;
        g_hostState.x += 0.01f;
        g_hostState.z += 0.005f;
        HookLab::DispatchTick(&g_hostState);

        bool insertDown =
            (GetAsyncKeyState(VK_INSERT) & 0x8000) != 0;

        if (insertDown && !previousInsert)
            Menu::Toggle();

        previousInsert = insertDown;

        const float clear[] = {
            0.05f, 0.05f, 0.06f, 1.0f
        };

        g_context->OMSetRenderTargets(
            1,
            &g_target,
            nullptr);

        g_context->ClearRenderTargetView(
            g_target,
            clear);

        Menu::Render();

        ImGui_ImplDX11_RenderDrawData(
            ImGui::GetDrawData());

        g_swap->Present(1, 0);
    }

    FreeLibrary(dll);
    Cleanup();

    DestroyWindow(g_hwnd);
    UnregisterClass(wc.lpszClassName, instance);

    return 0;
}
