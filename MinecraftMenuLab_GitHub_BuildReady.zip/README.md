# MinecraftMenuLab — Safe Hook Laboratory

This solution is an educational C++ DLL + Dear ImGui + DirectX 11 project.

It intentionally does **not** inject into Minecraft, scan Minecraft memory, patch
Minecraft code, or read/write another process. The DLL is loaded normally by the
included `TestHost` application, and `HookLab` provides a small in-process
simulation of a game tick/state callback.

## What is included

- `MenuDLL.dll` loaded by the included TestHost with normal `LoadLibraryW`
- Dear ImGui menu with INSERT toggle
- DX11 rendering
- Simulated tick hook callback
- Simulated player state: XYZ, FOV, brightness and tick count
- Hook install/remove controls in the menu
- Fullbright/FOV/coordinates examples that affect only TestHost state

## Build

1. Install Visual Studio 2022 with Desktop development with C++.
2. Open `MinecraftMenuLab.sln`.
3. Select `x64`.
4. Run `bootstrap-imgui.ps1` from the solution directory.
5. Build Solution.
6. Set `TestHost` as the startup project.
7. Run.
8. Press `INSERT`.
9. Open the `Hooks` tab to install/remove the simulated hook and observe state.

This is deliberately a test harness rather than a Minecraft client injector.
For Minecraft, use an official/mod-supported extension point such as the Bedrock
Script API/resource-pack system or a supported mod loader/API.
