# Build MenuDLL on GitHub

## 1. Create the repository

On GitHub, create a new repository. A blank repository is easiest.

## 2. Upload this project

Upload the contents of this ZIP to the repository root. Make sure these are
at the root:

- `MinecraftMenuLab.sln`
- `MenuDLL/`
- `TestHost/`
- `.github/workflows/build.yml`

Commit the files to `main`.

## 3. Run the build

Open the repository's **Actions** tab and select **Build MenuDLL**.

Click **Run workflow** if you want to start it manually.

The workflow uses Microsoft's Windows runner and MSBuild to build:

`Release | x64`

## 4. Download the DLL

When the workflow finishes, open the completed workflow run.

Under **Artifacts**, download:

`MenuDLL-x64-Release`

The ZIP artifact contains the resulting `MenuDLL.dll`.

This workflow builds the safe TestHost-compatible DLL. It does not contain
Minecraft process injection, remote-memory access, signature scanning against
Minecraft, or executable patching.
