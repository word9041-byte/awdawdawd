#include "HookLab.h"

namespace
{
    HookLab::TickCallback g_tickCallback = nullptr;
}

namespace HookLab
{
    void InstallTickHook(TickCallback callback)
    {
        g_tickCallback = callback;
    }

    void RemoveTickHook()
    {
        g_tickCallback = nullptr;
    }

    void DispatchTick(HostState* state)
    {
        if (g_tickCallback && state)
            g_tickCallback(state);
    }
}
