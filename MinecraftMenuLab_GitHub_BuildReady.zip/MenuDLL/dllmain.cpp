#include <Windows.h>
#include "Menu.h"

extern "C" __declspec(dllexport)
void MenuToggle()
{
    Menu::Toggle();
}

extern "C" __declspec(dllexport)
bool MenuIsOpen()
{
    return Menu::IsOpen();
}

BOOL APIENTRY DllMain(HMODULE, DWORD reason, LPVOID)
{
    if (reason == DLL_PROCESS_ATTACH)
        DisableThreadLibraryCalls(GetModuleHandleW(nullptr));

    return TRUE;
}
