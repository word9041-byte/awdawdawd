#pragma once
#include "HookLab.h"

namespace Menu
{
    bool Initialize(void* hwnd, void* device, void* context);
    void Toggle();
    bool IsOpen();
    void Render();
    void Shutdown();

    // Safe test-host hook controls.
    void InstallTestHooks();
    void RemoveTestHooks();
    const HookLab::HostState& GetObservedState();
}
