#include "Menu.h"
#include "imgui.h"
#include "backends/imgui_impl_win32.h"
#include "backends/imgui_impl_dx11.h"
#include <d3d11.h>

namespace
{
    bool g_open = false;
    bool g_fps = true;
    bool g_crosshair = false;
    bool g_coordinates = false;
    bool g_fullbright = false;
    bool g_hooks = true;

    HookLab::HostState g_observed{};
    float g_fovPreview = 90.0f;

    void OnTestHostTick(HookLab::HostState* state)
    {
        if (!state)
            return;

        // Read-only observation of the test host's state.
        g_observed = *state;

        // Safe demonstration: this changes only the host's own simulated state.
        if (g_fullbright)
            state->brightness = 2.0f;
        else
            state->brightness = 1.0f;

        state->fov = g_fovPreview;
    }
}

namespace Menu
{
    bool Initialize(void* hwnd, void* device, void* context)
    {
        IMGUI_CHECKVERSION();
        ImGui::CreateContext();

        ImGuiIO& io = ImGui::GetIO();
        io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
        ImGui::StyleColorsDark();

        if (!ImGui_ImplWin32_Init(hwnd))
            return false;

        if (!ImGui_ImplDX11_Init(
            static_cast<ID3D11Device*>(device),
            static_cast<ID3D11DeviceContext*>(context)))
            return false;

        if (g_hooks)
            InstallTestHooks();

        return true;
    }

    void Toggle()
    {
        g_open = !g_open;
    }

    bool IsOpen()
    {
        return g_open;
    }

    void InstallTestHooks()
    {
        HookLab::InstallTickHook(&OnTestHostTick);
        g_hooks = true;
    }

    void RemoveTestHooks()
    {
        HookLab::RemoveTickHook();
        g_hooks = false;
    }

    const HookLab::HostState& GetObservedState()
    {
        return g_observed;
    }

    void Render()
    {
        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();

        if (g_open)
        {
            ImGui::SetNextWindowSize(ImVec2(560, 460), ImGuiCond_FirstUseEver);
            ImGui::Begin("Minecraft Menu Lab", &g_open);

            if (ImGui::BeginTabBar("Tabs"))
            {
                if (ImGui::BeginTabItem("Visuals"))
                {
                    ImGui::Checkbox("FPS Counter", &g_fps);
                    ImGui::Checkbox("Coordinates", &g_coordinates);
                    ImGui::Checkbox("Crosshair", &g_crosshair);
                    ImGui::Checkbox("Fullbright test", &g_fullbright);
                    ImGui::SliderFloat("FOV preview", &g_fovPreview, 30.0f, 120.0f);
                    ImGui::EndTabItem();
                }

                if (ImGui::BeginTabItem("Hooks"))
                {
                    ImGui::TextWrapped(
                        "Safe hook laboratory: callbacks run only inside TestHost. "
                        "There is no Minecraft process injection, remote memory access, "
                        "signature scanning, or executable patching.");

                    if (g_hooks)
                    {
                        if (ImGui::Button("Remove simulated hooks"))
                            RemoveTestHooks();
                    }
                    else
                    {
                        if (ImGui::Button("Install simulated hooks"))
                            InstallTestHooks();
                    }

                    ImGui::Separator();
                    ImGui::Text("Hook state: %s", g_hooks ? "installed" : "removed");
                    ImGui::Text("Observed tick: %u", g_observed.tick);
                    ImGui::Text("Observed position: %.2f, %.2f, %.2f",
                        g_observed.x, g_observed.y, g_observed.z);
                    ImGui::Text("Simulated FOV: %.1f", g_observed.fov);
                    ImGui::Text("Simulated brightness: %.2f", g_observed.brightness);

                    ImGui::EndTabItem();
                }

                if (ImGui::BeginTabItem("Player"))
                {
                    ImGui::TextWrapped(
                        "Educational controls operate on TestHost's simulated "
                        "player state only.");
                    ImGui::EndTabItem();
                }

                if (ImGui::BeginTabItem("Debug"))
                {
                    ImGui::Text("ImGui: %s", IMGUI_VERSION);
                    ImGui::Text("Menu DLL active");
                    ImGui::Text("Press INSERT to toggle");
                    ImGui::Text("Test hooks: %s", g_hooks ? "ON" : "OFF");
                    ImGui::EndTabItem();
                }

                ImGui::EndTabBar();
            }

            ImGui::End();
        }

        if (g_fps)
        {
            ImGui::SetNextWindowBgAlpha(0.35f);
            ImGui::Begin("FPS", nullptr,
                ImGuiWindowFlags_NoDecoration |
                ImGuiWindowFlags_AlwaysAutoResize |
                ImGuiWindowFlags_NoInputs);
            ImGui::Text("FPS: %.0f", ImGui::GetIO().Framerate);
            ImGui::End();
        }

        if (g_crosshair)
        {
            auto* draw = ImGui::GetForegroundDrawList();
            const auto& display = ImGui::GetIO().DisplaySize;
            ImVec2 c(display.x * 0.5f, display.y * 0.5f);
            draw->AddLine(ImVec2(c.x - 6, c.y), ImVec2(c.x + 6, c.y),
                          IM_COL32(255,255,255,255), 1.0f);
            draw->AddLine(ImVec2(c.x, c.y - 6), ImVec2(c.x, c.y + 6),
                          IM_COL32(255,255,255,255), 1.0f);
        }

        if (g_coordinates)
        {
            ImGui::SetNextWindowBgAlpha(0.35f);
            ImGui::Begin("Coordinates", nullptr,
                ImGuiWindowFlags_NoDecoration |
                ImGuiWindowFlags_AlwaysAutoResize |
                ImGuiWindowFlags_NoInputs);
            ImGui::Text("XYZ: %.2f %.2f %.2f",
                g_observed.x, g_observed.y, g_observed.z);
            ImGui::End();
        }

        ImGui::Render();
    }

    void Shutdown()
    {
        RemoveTestHooks();
        ImGui_ImplDX11_Shutdown();
        ImGui_ImplWin32_Shutdown();
        ImGui::DestroyContext();
    }
}
