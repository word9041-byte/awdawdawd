#pragma once
#include <cstdint>

namespace HookLab
{
    // This state belongs to TestHost only. It is NOT Minecraft memory.
    struct HostState
    {
        float fov = 90.0f;
        float brightness = 1.0f;
        float x = 0.0f;
        float y = 64.0f;
        float z = 0.0f;
        std::uint32_t tick = 0;
    };

    using TickCallback = void (*)(HostState*);

    // Registers a callback with the TestHost simulation.
    // No external-process memory access or code patching is performed.
    void InstallTickHook(TickCallback callback);

    void RemoveTickHook();

    // Called by TestHost once per simulated frame/tick.
    void DispatchTick(HostState* state);
}
