$ErrorActionPreference = "Stop"
$tag = "v1.92.5b"
$zip = Join-Path $env:TEMP "imgui.zip"
$url = "https://github.com/ocornut/imgui/archive/refs/tags/$tag.zip"

Write-Host "Downloading Dear ImGui $tag..."
Invoke-WebRequest -Uri $url -OutFile $zip

$extract = Join-Path $env:TEMP "imgui_extract"
if (Test-Path $extract) { Remove-Item $extract -Recurse -Force }
Expand-Archive $zip -DestinationPath $extract -Force

$source = Get-ChildItem $extract -Directory | Select-Object -First 1
$destination = Join-Path $PSScriptRoot "imgui"

if (Test-Path $destination) { Remove-Item $destination -Recurse -Force }
New-Item -ItemType Directory $destination | Out-Null

Copy-Item "$($source.FullName)\*.h" $destination -Force
Copy-Item "$($source.FullName)\*.cpp" $destination -Force
Copy-Item "$($source.FullName)\backends" "$destination\backends" -Recurse -Force

Write-Host "ImGui installed in $destination"
